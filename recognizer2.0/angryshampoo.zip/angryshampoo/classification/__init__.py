default_model_file_path = './model.pkl'

from classification.knn import KNN