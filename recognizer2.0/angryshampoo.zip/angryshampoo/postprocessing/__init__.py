default_lexicon_file = './postprocessing/lexicon.txt'

from postprocessing.nearestlexiconentry import NearestLexiconEntry
from postprocessing.nearestwithpriors import NearestLexiconEntryWithPrior
import distancemeasures as distances