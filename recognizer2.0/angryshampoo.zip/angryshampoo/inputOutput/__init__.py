from inputOutput.wordio import read
from word import Character
from word import Word

from inputOutput.wordio import save